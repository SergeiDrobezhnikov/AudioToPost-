// Запуск через pm2: pm2 start ecosystem.config.js
module.exports = {
  apps: [
    {
      name: 'audiotopostbot',
      script: 'index.js',
      cwd: __dirname,
      instances: 1,            // ТОЛЬКО 1: long polling и SQLite не поддерживают несколько копий
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '500M',
      restart_delay: 3000,
      time: true               // метки времени в логах
    }
  ]
};
